$(async() => {
    const defaults = {
        active: true, 
        preset: '', 
        cps: 26, 
        clicks: 0, 
        cleared: 0
    }

    let {active, preset, cps, clicks, cleared} = await chrome.storage.local.get(defaults)
    let [activeTab] = await chrome.tabs.query({active: true, currentWindow: true, url: 'https://popcat.click/*'})

    if(activeTab) {
        try {
            let duration = await chrome.tabs.sendMessage(activeTab.id, {action: 'get-duration'})
            console.log(duration)

            $('.duration').text(duration)
        } 
        catch (error) {
            console.log(error)    
        }
    }
    
    // Set value of active toggle and bind listener to save changes
    $('#active').prop('checked', active).on('change', function() {
        chrome.storage.local.set({active: $(this).prop('checked')})
    })

    // Get registered commands (shortcuts)
    chrome.commands.getAll().then(commands => {
        let cmd = commands.find(c => c.name === 'toggle-clicker')
        
        //display the shortcut and bind click listener
        $('.toggle-shortkey').text(cmd?.shortcut || 'N/A').on('click', () => {
            chrome.tabs.create({url: 'chrome://extensions/shortcuts'})
        })
    })
    
    // Set value of preset and bind listener to save changes
    $('#preset').val(preset).on('change', function() {
        preset = $(this).val()
        chrome.storage.local.set({preset})
    
        if(preset === '') { 
            // Custom option selected, show range slider and custom cps
            $('.custom-cps-row, .range-container').show()
        }
        else {
            // Preset selected, hide the range slider and custom cps
            $('#cps').val(preset * 1).trigger('input')
            $('.custom-cps-row, .range-container').hide()
        }
    }).trigger('change') // Trigger the listener to toggle range slider visibility on page load

    // Set value of cps and bind listener to save changes
    $('#cps').val(cps).on('input', function() {
        // Convert the cps input to numberic value
        cps = $(this).val() * 1

        // Update the value of range slider and trigger listener
        $('#range').val(cps).trigger('input')
    })

    // Set the value of range slider and bind listener
    $('#range').val(cps).on('input', function() {
        // Get parameters required for calculating slider size
        const min = $(this).prop('min')
        const max = $(this).prop('max')
        cps = $(this).val() * 1
        
        // Calculate the and set the slider size
        const backgroundSize = (cps - min) * 100 / (max - min) + '% 100%'
        $(this).css({backgroundSize})
    
        // Update the cps value
        $('#cps').val(cps)
        chrome.storage.local.set({cps})
    }).trigger('input') // Trigger the listener to update the slider size on page load


    // Get the cookie with name: pop_count
    let cookie = await chrome.cookies.get({name: 'pop_count', url: 'https://popcat.click/'})
    let pops = (cookie?.value || 0) * 1
    
    $('.pops').text(pops)

    // Setup number formatter
    const formatter = Intl.NumberFormat('en', {notation: 'compact'})
    let totalClicks = clicks + pops

    $('.clicks').text(formatter.format(totalClicks))

    $('#pops').val(pops).on('input', function() {
        pops = $(this).val().trim() * 1
        $('.pops').text(pops)

        // Update clicker clicks text
        totalClicks = clicks + pops
        $('.clicks').text(formatter.format(totalClicks))

        let expiry = new Date()
        expiry.setDate(expiry.getDate() + 7)

        chrome.cookies.set({
            name: 'pop_count', 
            value: `${pops}`, 
            expirationDate: expiry.getTime()/1000, 
            url: 'https://popcat.click/'
        })
    })

    $('.red-eyes-cleared').text(formatter.format(cleared))
})