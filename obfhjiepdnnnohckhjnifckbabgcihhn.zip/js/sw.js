chrome.commands.onCommand.addListener(command => {
    chrome.storage.local.get({active: true}).then(data => {
        chrome.storage.local.set({active: !data.active})
    })
})