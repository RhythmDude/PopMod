let active = false
let cps
let timer
let startTime
let totalDuration = 0

chrome.storage.local.get({active: true, cps: 26}).then(data => {
    cps = data.cps

    if(data.active === true) start()
})

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if(request.action === 'get-duration') {
        const duration = getDuration()
        sendResponse(duration)
    }
})

chrome.storage.local.onChanged.addListener(changes => {
    for (const key in changes) {
        let {newValue} = changes[key]

        switch(key) {
            case 'active': {
                if(newValue === true) {
                    if(active === false) start()
                    else console.log('clicker already active')
                }
                else {
                    stop()
                }
                break
            }
            case 'cps':
                cps = newValue
                break
        }
    }
})

function start() {
    active = true
    startTime = Date.now()

    scheduleClick()
    console.log('[POPCAT HACK] Clicker started!')
}

function stop() {
    active = false
    clearTimeout(timer)

    if(startTime) {
        // Calculate the duration in seconds
        let duration = (Date.now() - startTime) / 1000

        // Add the duration to the total
        totalDuration += duration
        
        // Reset start time
        startTime = undefined
    }
}

function getDuration() {
    let currentTotalDuration

    if(startTime) {
        let currentDuration = (Date.now() - startTime) / 1000
        currentTotalDuration = totalDuration + currentDuration
    } 
    else {
        currentTotalDuration = totalDuration
    }

    let hours = (currentTotalDuration / 3600).toFixed(2)
    console.log(`[POPCAT HACK] Total Duration: ${hours} hours`)

    return hours
}

async function main() {
    if(!active) return console.log('[POPCAT HACK] Clicker stopped!')

    document.dispatchEvent(new KeyboardEvent('keydown', {key: 'g', ctrlKey: true}))
	document.dispatchEvent(new KeyboardEvent('keyup', {key: 'g', ctrlKey: true}))

    let {clicks} = await chrome.storage.local.get({clicks: 0})
    clicks += 1

    await chrome.storage.local.set({clicks})

    if(getCookieValue("bot") === "true") {
        clearTimeout(timer)

        let {cleared} = await chrome.storage.local.get({cleared: 0})
        cleared += 1

        await chrome.storage.local.set({cleared})
        
        document.cookie = "bot=;"
        location.reload()
    }
    else {
        scheduleClick()
    }
}

function scheduleClick() {
    timer = setTimeout(main, 1000 / cps)
}

function getCookieValue(name) {
    return document.cookie.match('(^|;)\\s*' + name + '\\s*=\\s*([^;]+)')?.pop() || ''
}